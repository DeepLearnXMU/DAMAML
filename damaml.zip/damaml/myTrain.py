from tqdm import tqdm
import torch.nn as nn

from utils.config import *
from models.TRADE import *
import copy

'''
python myTrain.py -dec= -bsz= -hdd= -dr= -lr=
'''

early_stop = args['earlyStop']

if args['dataset']=='multiwoz':
    from utils.utils_multiWOZ_DST import *
    early_stop = None
else:
    print("You need to provide the --dataset information")
    exit(1)

# Configure models and load data
avg_best, cnt, acc = float('-inf'), 0, 0.0
train, dev, test, test_special, lang, SLOTS_LIST, gating_dict, max_word = prepare_data_seq_maml(True, args['task'], False, batch_size=int(args['batch']))

model = globals()[args['decoder']](
    hidden_size=int(args['hidden']), 
    lang=lang, 
    path=args['path'], 
    task=args['task'], 
    lr=float(args['learn']), 
    dropout=float(args['drop']),
    slots=SLOTS_LIST,
    gating_dict=gating_dict, 
    nb_train_vocab=max_word)

scheduler_maml = lr_scheduler.ReduceLROnPlateau(model.maml_opt, mode='max', factor=0.5, patience=1,
                                                        min_lr=0.0001, verbose=True)

# print("[Info] Slots include ", SLOTS_LIST)
# print("[Info] Unpointable Slots include ", gating_dict)
maxStep = 0
for k in train:
    maxStep = max(maxStep, len(train[k]))
    train[k] = iter(train[k])
print("Read %s pairs train, %s domains"% (maxStep, len(train)))

INNER_STEP = 1
for epoch in range(200):
    print("Epoch:{}".format(epoch))
    # Run the train function
    pbar = tqdm(enumerate(range(maxStep // 2)),total=maxStep // 2)
    for i, _ in pbar:
        loss_stack = []
        init_state = copy.deepcopy(model.state_dict())
        for domain in train:
            if domain == 'UNK':
                continue
            model.load_state_dict(init_state)
            for _ in range(INNER_STEP):
                model.inner_opt.zero_grad()
                data = next(train[domain])
                tmp_loss = model.train_batch(data, int(args['clip']), SLOTS_LIST[1], reset=(i==0))
                tmp_loss.backward(retain_graph=False)
                clip_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), args['clip'])
                model.inner_opt.step()

            data = next(train[domain])
            loss = model.train_batch(data, int(args['clip']), SLOTS_LIST[1], reset=(i==0))
            loss_stack.append(loss)
            # model.optimize(args['clip'], 'inner')

        model.load_state_dict(init_state)
        model.maml_opt.zero_grad()
        loss_maml = torch.stack(loss_stack).sum(0) / (len(train.keys()) * INNER_STEP)
        loss_maml.backward()
        model.maml_opt.step()
        pbar.set_description("loss_maml: {}".format(loss_maml.item()))

    if((epoch+1) % int(args['evalp']) == 0):
        init_state = copy.deepcopy(model.state_dict())
        eval_loss = model.valid_maml(dev, SLOTS_LIST[1], init_state)
        model.load_state_dict(init_state)
        # model.scheduler.step(eval_loss)
        scheduler_maml.step(eval_loss)
        print("MODEL VALID Loss: %.5f"%eval_loss)

        if(eval_loss >= avg_best):
            avg_best = eval_loss
            cnt=0
            best_model = model
            model.save_model('%.5f' % (eval_loss))
            print("MODEL SAVED with Loss: %.5f"% (eval_loss))
        else:
            cnt+=1

        if(cnt == args["patience"] or (eval_loss==0.0 and early_stop==None)):
            print("Ran out of patient, early stop...")
            break
