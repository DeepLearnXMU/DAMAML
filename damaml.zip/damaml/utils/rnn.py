import math
import torch
import warnings
import itertools
import numbers

import torch
import torch.nn as nn
from torch.nn.modules.rnn import RNNCellBase
import torch.nn.functional as F
import torch.nn.utils.rnn
from torch.nn import Parameter
from torch.nn.utils.rnn import PackedSequence, pad_packed_sequence, pack_padded_sequence

from torch.nn import _VF

# _rnn_impls = {
#     'RNN_TANH': _VF.rnn_tanh,
#     'RNN_RELU': _VF.rnn_relu,
# }
#
# class GRUCell(nn.modules.rnn.RNNCellBase):
#     r"""A gated recurrent unit (GRU) cell
#
#     .. math::
#
#         \begin{array}{ll}
#         r = \sigma(W_{ir} x + b_{ir} + W_{hr} h + b_{hr}) \\
#         z = \sigma(W_{iz} x + b_{iz} + W_{hz} h + b_{hz}) \\
#         n = \tanh(W_{in} x + b_{in} + r * (W_{hn} h + b_{hn})) \\
#         h' = (1 - z) * n + z * h
#         \end{array}
#
#     where :math:`\sigma` is the sigmoid function, and :math:`*` is the Hadamard product.
#
#     Args:
#         input_size: The number of expected features in the input `x`
#         hidden_size: The number of features in the hidden state `h`
#         bias: If ``False``, then the layer does not use bias weights `b_ih` and
#             `b_hh`. Default: ``True``
#
#     Inputs: input, hidden
#         - **input** of shape `(batch, input_size)`: tensor containing input features
#         - **hidden** of shape `(batch, hidden_size)`: tensor containing the initial hidden
#           state for each element in the batch.
#           Defaults to zero if not provided.
#
#     Outputs: h'
#         - **h'** of shape `(batch, hidden_size)`: tensor containing the next hidden state
#           for each element in the batch
#
#     Shape:
#         - Input1: :math:`(N, H_{in})` tensor containing input features where
#           :math:`H_{in}` = `input_size`
#         - Input2: :math:`(N, H_{out})` tensor containing the initial hidden
#           state for each element in the batch where :math:`H_{out}` = `hidden_size`
#           Defaults to zero if not provided.
#         - Output: :math:`(N, H_{out})` tensor containing the next hidden state
#           for each element in the batch
#
#     Attributes:
#         weight_ih: the learnable input-hidden weights, of shape
#             `(3*hidden_size, input_size)`
#         weight_hh: the learnable hidden-hidden weights, of shape
#             `(3*hidden_size, hidden_size)`
#         bias_ih: the learnable input-hidden bias, of shape `(3*hidden_size)`
#         bias_hh: the learnable hidden-hidden bias, of shape `(3*hidden_size)`
#
#     .. note::
#         All the weights and biases are initialized from :math:`\mathcal{U}(-\sqrt{k}, \sqrt{k})`
#         where :math:`k = \frac{1}{\text{hidden\_size}}`
#
#     Examples::
#
#         >>> rnn = nn.GRUCell(10, 20)
#         >>> input = torch.randn(6, 3, 10)
#         >>> hx = torch.randn(3, 20)
#         >>> output = []
#         >>> for i in range(6):
#                 hx = rnn(input[i], hx)
#                 output.append(hx)
#     """
#
#     def __init__(self, input_size, hidden_size, bias=True):
#         super(GRUCell, self).__init__(input_size, hidden_size, bias, num_chunks=3)
#
#     def forward(self, input, domain_bias, hx=None):
#         # type: (Tensor, Optional[Tensor]) -> Tensor
#         self.check_forward_input(input)
#         if hx is None:
#             hx = torch.zeros(input.size(0), self.hidden_size, dtype=input.dtype, device=input.device)
#         self.check_forward_hidden(input, hx, '')
#         # print("yyo")
#         print(self.weight_ih.size())
#         print(domain_bias[:3 * self.hidden_size].view(-1, self.hidden_size).unsqueeze(-1).expand_as(torch.ones([3, self.hidden_size,
#                                                                                 self.hidden_size])).view(-1, self.hidden_size).size())
#         return _VF.gru_cell(
#             input, hx,
#             self.weight_ih * domain_bias[:3 * self.hidden_size].view(-1, self.hidden_size).unsqueeze(-1).expand_as(torch.ones([3, self.hidden_size,
#                                                                                 self.hidden_size])).view(-1, self.hidden_size),
#             self.weight_hh * domain_bias[3 * self.hidden_size:6 * self.hidden_size].view(-1, self.hidden_size).unsqueeze(-1).expand_as(torch.ones([3, self.hidden_size,
#                                                                                 self.hidden_size])).view(-1, self.hidden_size),
#             self.bias_ih * domain_bias[6 * self.hidden_size: 9 * self.hidden_size],
#             self.bias_hh * domain_bias[9 * self.hidden_size:],
#         )

class GRUCell(nn.Module):
    r"""A gated recurrent unit (GRU) cell

    .. math::

        \begin{array}{ll}
        r = \sigma(W_{ir} x + b_{ir} + W_{hr} h + b_{hr}) \\
        z = \sigma(W_{iz} x + b_{iz} + W_{hz} h + b_{hz}) \\
        n = \tanh(W_{in} x + b_{in} + r * (W_{hn} h + b_{hn})) \\
        h' = (1 - z) * n + z * h
        \end{array}

    where :math:`\sigma` is the sigmoid function.

    Args:
        input_size: The number of expected features in the input `x`
        hidden_size: The number of features in the hidden state `h`
        bias: If `False`, then the layer does not use bias weights `b_ih` and
            `b_hh`. Default: `True`

    Inputs: input, hidden
        - **input** of shape `(batch, input_size)`: tensor containing input features
        - **hidden** of shape `(batch, hidden_size)`: tensor containing the initial hidden
          state for each element in the batch.
          Defaults to zero if not provided.

    Outputs: h'
        - **h'** of shape `(batch, hidden_size)`: tensor containing the next hidden state
          for each element in the batch

    Attributes:
        weight_ih: the learnable input-hidden weights, of shape
            `(3*hidden_size x input_size)`
        weight_hh: the learnable hidden-hidden weights, of shape
            `(3*hidden_size x hidden_size)`
        bias_ih: the learnable input-hidden bias, of shape `(3*hidden_size)`
        bias_hh: the learnable hidden-hidden bias, of shape `(3*hidden_size)`

    Examples::

        >>> rnn = nn.GRUCell(10, 20)
        >>> input = torch.randn(6, 3, 10)
        >>> hx = torch.randn(3, 20)
        >>> output = []
        >>> for i in range(6):
                hx = rnn(input[i], hx)
                output.append(hx)
    """

    def __init__(self, input_size, hidden_size, bias=True):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.bias = bias
        self.weight_ih = Parameter(torch.Tensor(3 * hidden_size, input_size))
        self.weight_hh = Parameter(torch.Tensor(3 * hidden_size, hidden_size))

        if bias:
            self.bias_ih = Parameter(torch.Tensor(3 * hidden_size))
            self.bias_hh = Parameter(torch.Tensor(3 * hidden_size))
        else:
            self.register_parameter('bias_ih', None)
            self.register_parameter('bias_hh', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            nn.init.uniform_(weight, -stdv, stdv)

    def forward(self, input, domain_bias, hx=None):
        w_ih, b_ih = self.weight_ih, self.bias_ih
        w_hh, b_hh = self.weight_hh, self.bias_hh
        gi = F.linear(input, w_ih, None) * domain_bias[:,:3 * self.hidden_size] + \
             b_ih * domain_bias[:,3 * self.hidden_size : 6 * self.hidden_size]
        gh = F.linear(hx, w_hh, None) * domain_bias[:,6 * self.hidden_size: 9 * self.hidden_size] + \
             b_hh * domain_bias[:,9 * self.hidden_size:]
        i_zr, i_n = gi.split([self.hidden_size * 2, self.hidden_size], -1)
        h_zr, h_n = gh.split([self.hidden_size * 2, self.hidden_size], -1)

        i_r, i_i = i_zr.chunk(2, 1)
        h_r, h_i = h_zr.chunk(2, 1)

        resetgate = torch.sigmoid(i_r + h_r)
        inputgate = torch.sigmoid(i_i + h_i)
        newgate = torch.tanh(i_n + resetgate * h_n)
        h = newgate + inputgate * (hx - newgate)

        return h
